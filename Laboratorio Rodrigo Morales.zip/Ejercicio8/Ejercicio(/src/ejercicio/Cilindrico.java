/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio;

/**
 *
 * @author Rodrigo
 */
public class Cilindrico extends Tanque{

    public String Tipo;
    
    /**
     * Constructor
     * @param Id
     * @param Altura
     * @param Largo
     * @param GastoXValvula 
     */
    public Cilindrico(int Id, double Altura, double Largo, double GastoXValvula) {
        super(Id, Altura, 0, Largo, GastoXValvula);
        this.Capacidad = GetCapacidad(this.Altura, this.Largo);
        this.Disponible = this.Capacidad;
        Tipo = "Cilindrico";
    }

    /**
     * Método para calcular la capacidad de un cilindro
     * @param Alto
     * @param Ancho
     * @return la caoacidad del tanque
     */
    public double GetCapacidad(double Alto, double Ancho){
          return (2*3.14*(Ancho * Ancho)* Alto);}
    
    
}
