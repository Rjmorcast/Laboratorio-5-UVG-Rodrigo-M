/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

/**
 *
 * @author Rodrigo
 */
public class BaseDatos {
 EntityManagerFactory emf;  // para especificar la Persistent Unit y conexion a la base de datos
 EntityManager em; // manejador de las entidades en la base de datos
 
 /**
  Constructor de la clase que maneja la persistencia de los obejtos
 */
 public BaseDatos(){
        emf = javax.persistence.Persistence.createEntityManagerFactory("Ejercicio_PU");
        em = emf.createEntityManager();
    }  
/**
 * Agrega una fila más a la tabla bitacora que lleva control de las valvulas
 * @param V
 * @throws SQLNotConnectedException 
 */ 
public void addBitacora(Bitacora V) throws SQLNotConnectedException{
    Bitacora n = new Bitacora(0, 0, "", "");
    n = V;
    em.getTransaction().begin();// grabar el docente en la base de datos
    em.persist(n);
    em.getTransaction().commit();
    em.close();
    emf.close();
}


/**
 * Cierra la conexión con la base de datos
 */
public void closedb(){
    em.close();
    emf.close();
}

}
