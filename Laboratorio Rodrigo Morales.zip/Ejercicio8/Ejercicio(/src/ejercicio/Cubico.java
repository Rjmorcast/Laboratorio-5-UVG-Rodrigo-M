/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio;

/**
 *
 * @author Rodrigo
 */
public class Cubico extends Tanque {
    
    public String Tipo;
    
    public Cubico(int Id, double Altura, double Profundidad, double Largo, double GastoXValvula) {
        super(Id, Altura, Profundidad, Largo, GastoXValvula);
        this.Capacidad = GetCapacidad(this.Altura, this.Largo, this.Profundidad);
        this.Disponible = this.Capacidad;
        Tipo = "Cubico";
    }
    
}
