/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio;

import java.awt.Component;
import java.lang.reflect.Array;
import javax.swing.JOptionPane;

/**
 *
 * @author Rodrigo
 */
public class Tanque {
    public int Id;
    public String Tipo;
    public double Profundidad;
    public double Altura;
    public double Largo;
    public Valvula[] Valvulas = new Valvula[10] ;
    public double Capacidad;
    public double Disponible;
    public double GastoPorValvula;
 
    /**
     * Constructor de un tanque
     * @param Id
     * @param Altura
     * @param Profundidad
     * @param Largo
     * @param GastoXValvula 
     */
    public Tanque(int Id, double Altura, double Profundidad, double Largo, double GastoXValvula){
        this.Id = Id;
        this.Altura = Altura;
        this.Profundidad = Profundidad;
        this.Largo = Largo;
        this.GastoPorValvula =GastoXValvula;
        //Crea las 10 valvulas
        for (int x = 0; x<10;x++){
            Valvula V = new Valvula(this.Id,x,this.GastoPorValvula);
            Valvulas[x]= V;
        }
    }
    
    /**
     * Conseguir la capacidad del tanque
     * @param Alto
     * @param Ancho
     * @param largo
     * @return la capacidad en litros 
     */
    public double GetCapacidad(double Alto, double Ancho, double largo){
            return (2*3.14*(Ancho * Ancho)* Alto);
    }
    /**
     * Abre una valvula
     * @param id
     * @param Fecha
     * @return mensaje de estado de la  operacion 
     */
    public String AbrirValvula(int id, String Fecha) throws SQLNotConnectedException{
        double Porcentaje = (Disponible/Capacidad)*100;
        if (Porcentaje > 25){
            if ("Cerrada".equals(Valvulas[id].Estado)){
                    Valvulas[id].Abrir(Fecha);
                    Disponible = Disponible - Valvulas[id].Gasto;
                    Revisar(Fecha);
                    return "Valvula Abierta con exito";
            } else {
                return "La valvula ya está abierta";
            }
        } else {
            Revisar(Fecha);
            return "No hay suficiente agua en el tanque";
        }
    }
    /**
     * Cerrar valvula
     * @param id
     * @param Fecha
     * @return mensaje de estado de la operacion
     */
    public String CerrarValvula(int id, String Fecha) throws SQLNotConnectedException{
        if ("Abierta".equals(Valvulas[id].Estado)){
            Valvulas[id].Cerrar(Fecha);
            Revisar(Fecha);
            return "Valvula Cerrada Con exito";
        } else { 
            Revisar(Fecha);
            return "La valvula ya está cerrada";
        }
    }
    /**
     * Revisa si el tanque aun tiene suficiente agua 
     * @param Fecha 
     */
    public void Revisar(String Fecha) throws SQLNotConnectedException{
       double Porcentaje = (Disponible/Capacidad)*100;
       if (Porcentaje <= 10){
           for (int x=0; x<9; x++){
               if ("Abierta".equals(Valvulas[x].Estado)){
                Valvulas[x].Cerrar(Fecha);
               }
           }
           Component frame = null;
           JOptionPane.showMessageDialog(frame,"La capacidad del tanque está muy baja");
       }
    }
    /**
     * 
     * @return devuelve la cantidad de valvulas abiertas
     */
    public int ValvulasEnUso(){
        int VeU=0;//Abreviación de Valvulas en Uso
        for (int x=0; x<9;x++){
            if(Valvulas[x].Estado=="Abierta"){
                VeU++;
            }
        }
        return VeU;
    }
}
