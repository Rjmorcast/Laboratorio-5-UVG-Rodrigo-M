/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio;

/**
 *
 * @author Rodrigo
 */
public class Acueducto {
    public Tanque[] Tanques = new Tanque[10];
    BaseDatos db = new BaseDatos();
 /**
  * Constructor
  */  
public Acueducto(){
    Tanques[0]= new Cilindrico(0,20,20,5);
    Tanques[1]= new Cilindrico(1,50,60,5);
    Tanques[2]= new Cilindrico(2,90,80,15);
    Tanques[3]= new Cilindrico(3,20,20,2);
    Tanques[4]= new Cubico(4,20,20,20,5);
    Tanques[5]= new Cubico(5,100,1000,80,15);
    Tanques[6]= new Cubico(6,20,20,20,1);
    Tanques[7]= new Ortogonal(7,40,80,10,5);
    Tanques[8]= new Ortogonal(8,60,80,90,20);
    Tanques[9]= new Ortogonal(9,10,10,10,0.5);
}
/**
 * 
 * @return  devuelve la disponibilidad en litros de un tanque
 */
public double GetDisponibilidad(){
    double disponible =0;
    for (int x=0; x<9;x++){
        disponible = disponible + Tanques[x].Disponible;
    }
    return disponible;
}
/**
 * 
 * @param Tipo
 * @return devuevle la cantidad de valvulas abiertas por tipo de tanque
 */
public int GetValvulas(String Tipo){
    int v =0;
    for (int x=0;x<9;x++){
        if (Tanques[x].Tipo == Tipo){
            v = v + Tanques[x].ValvulasEnUso();
        }
    }
    return v;
}
/**
 * Abrir valvula
 * @param idtanque
 * @param idvalvula
 * @param Fecha
 * @return mensaje de la operacion
 */
public String AbrirValvula(int idtanque, int idvalvula, String Fecha) throws SQLNotConnectedException{
    return Tanques[idtanque].AbrirValvula(idvalvula, Fecha);
}
/**
 * Cerrar valvula
 * @param idtanque
 * @param idvalvula
 * @param Fecha
 * @return mensaje de la operacion
 */
public String CerrarValvula(int idtanque, int idvalvula, String Fecha) throws SQLNotConnectedException{
    return Tanques[idtanque].CerrarValvula(idvalvula, Fecha);
}
}
