/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio;

import java.util.ArrayList;

/**
 *
 * @author Rodrigo
 */
public class Valvula {
    public int TanqueID;
    public int Id; //Id de la valvula
    //public ArrayList<String> Bitacora = new ArrayList<>(); //Bitacora de movimientos
    public String Estado;//Estado (Abierto / Cerrado)
    public double Gasto; //Gasto en litros cada vez que se abre
    
    /**
     * Método Constructor de las valvulas
     * @param Id id valvula
     * @param Gasto gasto de la valvua
     */
    public Valvula(int tanqueID, int Id, double Gasto){
        this.TanqueID = tanqueID;
        this.Id = Id;
        this.Gasto = Gasto;
        this.Estado = "Cerrada";
    }
    /**
     * Método para abrir una valvula
     * @param Fecha 
     */
    public void Abrir (String Fecha) throws SQLNotConnectedException{
        this.Estado = "Abierta";
        //Bitacora.add(Fecha+" "+Estado);
        Bitacora B = new Bitacora(this.TanqueID,Id,Fecha,Estado);
        BaseDatos db = new BaseDatos();
        db.addBitacora(B);
    }
    /**
     * Método para cerrar una valvula
     * @param Fecha 
     */
    public void Cerrar(String Fecha) throws SQLNotConnectedException{
        this.Estado = "Cerrada";
        Bitacora B = new Bitacora(this.TanqueID,Id,Fecha,Estado);
        BaseDatos db = new BaseDatos();
        db.addBitacora(B);
        //Bitacora.add(Fecha+" "+Estado);
    }
}
